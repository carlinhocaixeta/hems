# coding=utf-8


def init():
    print ("Modulo de aplicaçoes externas sendo executado!")




