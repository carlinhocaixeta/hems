from django.apps import AppConfig


class ApiCloudConfig(AppConfig):
    name = 'api_cloud'
