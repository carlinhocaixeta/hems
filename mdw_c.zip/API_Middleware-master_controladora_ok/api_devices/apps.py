from django.apps import AppConfig


class ApiDevicesConfig(AppConfig):
    name = 'api_devices'
