__all__ = ['aplicacoes','comunicacao_aplicacao','comunicacao_dispositivos','dados']
